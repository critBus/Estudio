<template>
  <v-container>
    <v-row justify="space-around">
      <v-col cols="auto">
        <div class="text-center">
          <v-sheet border="primary thin" class="mx-auto" height="64" width="64" rounded></v-sheet>
          <div class="text-caption">"primary thin"</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <v-sheet border="success sm" height="64" width="64" rounded></v-sheet>
          <div class="text-caption">"sucess sm"</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <v-sheet border="info md" height="64" width="64" rounded></v-sheet>
          <div class="text-caption">"info md"</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <v-sheet border="warning lg" height="64" width="64" rounded></v-sheet>
          <div class="text-caption">"warning lg"</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <v-sheet border="error xl" height="64" width="64" rounded></v-sheet>
          <div class="text-caption">"error xl"</div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>
