<template>
  <v-sheet class="d-inline-flex bg-surface-variant">
    <v-sheet class="ma-2 pa-2">
      I'm a single element in an inline flexbox container!
    </v-sheet>
  </v-sheet>
</template>
