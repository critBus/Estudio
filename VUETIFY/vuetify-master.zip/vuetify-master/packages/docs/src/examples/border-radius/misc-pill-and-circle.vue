<template>
  <v-container>
    <v-row justify="space-around">
      <v-col cols="auto">
        <div class="text-center">
          <div class="bg-surface-variant rounded-pill mx-auto" style="height: 64px; width: 164px;"></div>
          <div class="text-caption">rounded-pill</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <div class="bg-surface-variant rounded-circle mx-auto" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">rounded-circle</div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>
