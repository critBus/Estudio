<template>
  <v-container class="text-center">
    <v-btn
      color="primary"
      rounded="pill"
      text="Update Account"
      flat
    ></v-btn>
  </v-container>
</template>
