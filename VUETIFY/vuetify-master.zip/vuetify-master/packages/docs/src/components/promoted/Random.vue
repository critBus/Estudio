<template>
  <PromotedVuetify class="mb-5" />
</template>
