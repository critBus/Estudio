<template>
  <AppHeadline size="subtitle-2" weight="black" />
</template>

<script setup>
  //
</script>
